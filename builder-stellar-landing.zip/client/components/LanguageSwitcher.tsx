import { useTranslation } from "react-i18next";
import { useAppSettings, Language } from "@/contexts/AppSettingsContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Globe } from "lucide-react";

export function LanguageSwitcher() {
  const { t } = useTranslation();
  const { language, setLanguage } = useAppSettings();

  const languages: { code: Language; name: string; flag: string }[] = [
    { code: "en", name: t("languages.en"), flag: "🇬🇧" },
    { code: "lt", name: t("languages.lt"), flag: "🇱🇹" },
    { code: "ru", name: t("languages.ru"), flag: "🇷🇺" },
  ];

  return (
    <Select
      value={language}
      onValueChange={(value: Language) => setLanguage(value)}
    >
      <SelectTrigger className="w-[180px]">
        <div className="flex items-center space-x-2">
          <Globe className="w-4 h-4" />
          <SelectValue />
        </div>
      </SelectTrigger>
      <SelectContent>
        {languages.map((lang) => (
          <SelectItem key={lang.code} value={lang.code}>
            <div className="flex items-center space-x-2">
              <span>{lang.flag}</span>
              <span>{lang.name}</span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
