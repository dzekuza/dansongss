import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useEmailNotifications } from "@/hooks/use-email-notifications";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Mail,
  Bell,
  Calendar,
  Users,
  QrCode,
  Settings,
  Send,
} from "lucide-react";

export function EmailNotificationSettings() {
  const { user } = useAuth();
  const { sendTestEmail, loading } = useEmailNotifications();
  const [testEmail, setTestEmail] = useState(user?.email || "");
  const [notifications, setNotifications] = useState({
    eventCreated: true,
    eventReminders: true,
    eventUpdated: true,
    qrCodeGenerated: false,
    teamInvites: true,
  });

  const [reminderTiming, setReminderTiming] = useState("24"); // hours before event

  const handleNotificationToggle = (key: string, value: boolean) => {
    setNotifications((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleTestEmail = async () => {
    if (testEmail) {
      await sendTestEmail(testEmail);
    }
  };

  return (
    <div className="space-y-6">
      {/* Email Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Mail className="w-5 h-5" />
            <span>Email Configuration</span>
          </CardTitle>
          <CardDescription>
            Configure your email preferences and test email delivery
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={user?.email || ""}
                disabled
                className="bg-gray-50 dark:bg-gray-800"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                This is your account email address
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="test-email">Test Email Address</Label>
              <div className="flex space-x-2">
                <Input
                  id="test-email"
                  type="email"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                  placeholder="Enter email to test"
                />
                <Button
                  onClick={handleTestEmail}
                  disabled={loading || !testEmail}
                  size="sm"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Test
                </Button>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
            <div className="flex items-start space-x-2">
              <Settings className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900 dark:text-blue-300">
                  Email Service Status
                </h4>
                <p className="text-sm text-blue-700 dark:text-blue-400">
                  Emails are sent from{" "}
                  <code className="bg-blue-100 dark:bg-blue-800 px-1 rounded">
                    notifications@teamup.lt
                  </code>
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                  Make sure to check your spam folder if you don't receive test
                  emails
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bell className="w-5 h-5" />
            <span>Notification Preferences</span>
          </CardTitle>
          <CardDescription>
            Choose which email notifications you want to receive
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Event Notifications */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Calendar className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">Event Created</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Get notified when you create a new event
                  </p>
                </div>
              </div>
              <Switch
                checked={notifications.eventCreated}
                onCheckedChange={(checked) =>
                  handleNotificationToggle("eventCreated", checked)
                }
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Bell className="w-5 h-5 text-orange-600" />
                <div>
                  <p className="font-medium">Event Reminders</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Receive reminders before your events
                  </p>
                </div>
              </div>
              <Switch
                checked={notifications.eventReminders}
                onCheckedChange={(checked) =>
                  handleNotificationToggle("eventReminders", checked)
                }
              />
            </div>

            {notifications.eventReminders && (
              <div className="ml-8 space-y-2">
                <Label htmlFor="reminder-timing">Reminder Timing</Label>
                <Select
                  value={reminderTiming}
                  onValueChange={setReminderTiming}
                >
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 hour before</SelectItem>
                    <SelectItem value="6">6 hours before</SelectItem>
                    <SelectItem value="24">24 hours before</SelectItem>
                    <SelectItem value="48">48 hours before</SelectItem>
                    <SelectItem value="168">1 week before</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Settings className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium">Event Updates</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Get notified when event details are changed
                  </p>
                </div>
              </div>
              <Switch
                checked={notifications.eventUpdated}
                onCheckedChange={(checked) =>
                  handleNotificationToggle("eventUpdated", checked)
                }
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <QrCode className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="font-medium">QR Code Generated</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Receive QR codes via email when generated
                  </p>
                </div>
              </div>
              <Switch
                checked={notifications.qrCodeGenerated}
                onCheckedChange={(checked) =>
                  handleNotificationToggle("qrCodeGenerated", checked)
                }
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Users className="w-5 h-5 text-indigo-600" />
                <div>
                  <p className="font-medium">Team Invitations</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Get notified about team member invitations
                  </p>
                </div>
              </div>
              <Switch
                checked={notifications.teamInvites}
                onCheckedChange={(checked) =>
                  handleNotificationToggle("teamInvites", checked)
                }
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Email Templates Preview */}
      <Card>
        <CardHeader>
          <CardTitle>Email Templates</CardTitle>
          <CardDescription>
            Preview of the email templates that will be sent
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                title: "Event Created",
                description: "Confirmation email when creating events",
                color:
                  "bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300",
                icon: "🎉",
              },
              {
                title: "Event Reminder",
                description: "Reminder email before events",
                color:
                  "bg-orange-100 dark:bg-orange-900/20 text-orange-800 dark:text-orange-300",
                icon: "⏰",
              },
              {
                title: "Event Updated",
                description: "Notification when event details change",
                color:
                  "bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300",
                icon: "📝",
              },
              {
                title: "QR Code",
                description: "QR code delivery email",
                color:
                  "bg-purple-100 dark:bg-purple-900/20 text-purple-800 dark:text-purple-300",
                icon: "📱",
              },
              {
                title: "Team Invite",
                description: "Team member invitation email",
                color:
                  "bg-indigo-100 dark:bg-indigo-900/20 text-indigo-800 dark:text-indigo-300",
                icon: "👥",
              },
            ].map((template) => (
              <div
                key={template.title}
                className={`p-4 rounded-lg ${template.color}`}
              >
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-lg">{template.icon}</span>
                  <h4 className="font-medium">{template.title}</h4>
                </div>
                <p className="text-sm opacity-80">{template.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Save Settings */}
      <div className="flex justify-end">
        <Button className="bg-gradient-to-r from-brand-purple to-brand-blue">
          Save Notification Settings
        </Button>
      </div>
    </div>
  );
}
