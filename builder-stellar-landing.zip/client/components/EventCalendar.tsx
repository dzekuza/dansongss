import { useState } from "react";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isToday,
  addMonths,
  subMonths,
  setMonth,
  setYear,
  getYear,
  getMonth,
} from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Users,
  DollarSign,
  Music,
  Coffee,
  UserCheck,
  Building2,
  Edit,
  Eye,
  QrCode,
  Trash2,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
} from "lucide-react";

interface Event {
  id: string;
  name: string;
  description: string;
  venue: string;
  date: string;
  time: string;
  status: "upcoming" | "live" | "completed" | "cancelled";
  type: "dj" | "barista" | "host" | "company";
  earnings: number;
  attendees: number;
  requests?: number;
  orders?: number;
  assignedStaff?: {
    dj?: string;
    barista?: string;
    host?: string;
  };
}

interface EventCalendarProps {
  events: Event[];
  onViewLive: (eventId: string) => void;
  onGenerateQR: (eventId: string) => void;
  onEditEvent: (eventId: string) => void;
  onDeleteEvent: (eventId: string) => void;
}

export function EventCalendar({
  events,
  onViewLive,
  onGenerateQR,
  onEditEvent,
  onDeleteEvent,
}: EventCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showEventModal, setShowEventModal] = useState(false);

  // Get events for a specific date
  const getEventsForDate = (date: Date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    return events.filter((event) => event.date === dateStr);
  };

  const getEventColor = (event: Event) => {
    // Assign colors based on event type and status for variety
    if (event.status === "live") {
      return "bg-red-500"; // Red for live events
    }

    switch (event.type) {
      case "dj":
        return event.status === "upcoming" ? "bg-blue-500" : "bg-purple-500";
      case "barista":
        return event.status === "upcoming" ? "bg-green-500" : "bg-teal-500";
      case "host":
        return event.status === "upcoming" ? "bg-orange-500" : "bg-yellow-500";
      case "company":
        return event.status === "upcoming" ? "bg-indigo-500" : "bg-pink-500";
      default:
        return "bg-gray-500";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "dj":
        return Music;
      case "barista":
        return Coffee;
      case "host":
        return UserCheck;
      case "company":
        return Building2;
      default:
        return CalendarIcon;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "dj":
        return "bg-brand-purple/10 text-brand-purple dark:bg-brand-purple/20";
      case "barista":
        return "bg-brand-blue/10 text-brand-blue dark:bg-brand-blue/20";
      case "host":
        return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400";
      case "company":
        return "bg-gradient-to-r from-brand-purple to-brand-blue text-white";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
    }
  };

  const handleEventClick = (event: Event) => {
    setSelectedEvent(event);
    setShowEventModal(true);
  };

  const handlePrevMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };

  const handleMonthSelect = (monthIndex: number) => {
    setCurrentDate(setMonth(currentDate, monthIndex));
  };

  const handleYearSelect = (year: number) => {
    setCurrentDate(setYear(currentDate, year));
  };

  // Generate year range (current year ± 10 years)
  const currentYear = getYear(currentDate);
  const yearRange = Array.from({ length: 21 }, (_, i) => currentYear - 10 + i);

  // Month names
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  // Generate calendar grid
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);

  // Get all days to show (including previous/next month days to fill the grid)
  const calendarStart = new Date(monthStart);
  calendarStart.setDate(calendarStart.getDate() - monthStart.getDay());

  const calendarEnd = new Date(monthEnd);
  calendarEnd.setDate(calendarEnd.getDate() + (6 - monthEnd.getDay()));

  const calendarDays = eachDayOfInterval({
    start: calendarStart,
    end: calendarEnd,
  });

  const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900 border border-gray-700 shadow-2xl">
        <CardContent className="p-0">
          {/* Calendar Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-700 bg-gray-800">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                {/* Month Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="text-2xl font-bold text-white hover:text-gray-300 hover:bg-gray-700 p-2"
                    >
                      {format(currentDate, "MMMM")}
                      <ChevronDown className="ml-1 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-gray-800 border-gray-700">
                    {monthNames.map((month, index) => (
                      <DropdownMenuItem
                        key={month}
                        onClick={() => handleMonthSelect(index)}
                        className="text-white hover:bg-gray-700 cursor-pointer"
                      >
                        {month}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* Year Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="text-2xl font-bold text-white hover:text-gray-300 hover:bg-gray-700 p-2"
                    >
                      {format(currentDate, "yyyy")}
                      <ChevronDown className="ml-1 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-gray-800 border-gray-700 max-h-60 overflow-y-auto">
                    {yearRange.map((year) => (
                      <DropdownMenuItem
                        key={year}
                        onClick={() => handleYearSelect(year)}
                        className="text-white hover:bg-gray-700 cursor-pointer"
                      >
                        {year}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handlePrevMonth}
                  className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleNextMonth}
                  className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentDate(new Date())}
              className="bg-gray-700 border-gray-600 text-white hover:bg-gray-600"
            >
              Today
            </Button>
          </div>

          {/* Week Days Header */}
          <div className="grid grid-cols-7 border-b border-gray-700">
            {weekDays.map((day) => (
              <div
                key={day}
                className="p-3 text-center text-sm font-medium text-gray-400 bg-gray-800"
              >
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7">
            {calendarDays.map((day, index) => {
              const dayEvents = getEventsForDate(day);
              const isCurrentMonth = isSameMonth(day, currentDate);
              const isTodayDate = isToday(day);

              return (
                <div
                  key={index}
                  className={`min-h-[100px] border-r border-b border-gray-700 p-1 ${
                    !isCurrentMonth ? "bg-gray-800/50" : "bg-gray-900"
                  } hover:bg-gray-800/30 transition-colors`}
                >
                  {/* Date Number */}
                  <div className="flex justify-start items-center mb-1">
                    <span
                      className={`text-sm font-medium ${
                        !isCurrentMonth
                          ? "text-gray-600"
                          : isTodayDate
                            ? "text-white bg-blue-500 rounded-full w-6 h-6 flex items-center justify-center text-xs"
                            : "text-gray-300"
                      }`}
                    >
                      {format(day, "d")}
                    </span>
                  </div>

                  {/* Events */}
                  <div className="space-y-0.5">
                    {dayEvents.slice(0, 4).map((event, eventIndex) => (
                      <div
                        key={event.id}
                        onClick={() => handleEventClick(event)}
                        className={`text-xs px-2 py-1 rounded-md cursor-pointer truncate ${getEventColor(
                          event,
                        )} text-white hover:opacity-90 transition-opacity font-medium shadow-sm`}
                        title={`${event.name} at ${event.time}`}
                        style={{
                          maxWidth: "calc(100% - 2px)",
                          minHeight: "18px",
                          display: "flex",
                          alignItems: "center",
                        }}
                      >
                        {event.name}
                      </div>
                    ))}
                    {dayEvents.length > 4 && (
                      <div className="text-xs text-gray-500 px-1 py-0.5">
                        +{dayEvents.length - 4} more
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Event Details Modal */}
      <Dialog open={showEventModal} onOpenChange={setShowEventModal}>
        <DialogContent className="max-w-2xl">
          {selectedEvent && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center space-x-3">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center ${getTypeColor(
                      selectedEvent.type,
                    )}`}
                  >
                    {(() => {
                      const TypeIcon = getTypeIcon(selectedEvent.type);
                      return <TypeIcon className="w-6 h-6" />;
                    })()}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{selectedEvent.name}</h3>
                    <Badge
                      className={`${getEventColor(selectedEvent)} text-white text-xs mt-1`}
                    >
                      {selectedEvent.status === "live" && (
                        <div className="w-2 h-2 bg-white rounded-full mr-1 animate-pulse" />
                      )}
                      {selectedEvent.status.toUpperCase()}
                    </Badge>
                  </div>
                </DialogTitle>
                <DialogDescription>
                  {selectedEvent.description}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {/* Event Details */}
                <div className="grid grid-cols-1 gap-3">
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                    <MapPin className="w-4 h-4" />
                    <span>{selectedEvent.venue}</span>
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center space-x-2">
                      <CalendarIcon className="w-4 h-4" />
                      <span>
                        {new Date(selectedEvent.date).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4" />
                      <span>{selectedEvent.time}</span>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                      <Users className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    </div>
                    <div>
                      <p className="text-lg font-bold text-gray-900 dark:text-white">
                        {selectedEvent.attendees}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Attendees
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="text-lg font-bold text-green-600">
                        ${selectedEvent.earnings}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Earnings
                      </p>
                    </div>
                  </div>
                </div>

                {/* Additional Stats */}
                {(selectedEvent.requests !== undefined ||
                  selectedEvent.orders !== undefined) && (
                  <div className="grid grid-cols-2 gap-4">
                    {selectedEvent.requests !== undefined && (
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-brand-purple/10 rounded-lg flex items-center justify-center">
                          <Music className="w-4 h-4 text-brand-purple" />
                        </div>
                        <div>
                          <p className="text-lg font-bold text-gray-900 dark:text-white">
                            {selectedEvent.requests}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Requests
                          </p>
                        </div>
                      </div>
                    )}
                    {selectedEvent.orders !== undefined && (
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-brand-blue/10 rounded-lg flex items-center justify-center">
                          <Coffee className="w-4 h-4 text-brand-blue" />
                        </div>
                        <div>
                          <p className="text-lg font-bold text-gray-900 dark:text-white">
                            {selectedEvent.orders}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Orders
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Assigned Staff */}
                {selectedEvent.assignedStaff && (
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
                      Assigned Staff:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {selectedEvent.assignedStaff.dj && (
                        <Badge
                          variant="outline"
                          className="bg-brand-purple/5 border-brand-purple/20"
                        >
                          DJ: {selectedEvent.assignedStaff.dj}
                        </Badge>
                      )}
                      {selectedEvent.assignedStaff.barista && (
                        <Badge
                          variant="outline"
                          className="bg-brand-blue/5 border-brand-blue/20"
                        >
                          Barista: {selectedEvent.assignedStaff.barista}
                        </Badge>
                      )}
                      {selectedEvent.assignedStaff.host && (
                        <Badge
                          variant="outline"
                          className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800"
                        >
                          Host: {selectedEvent.assignedStaff.host}
                        </Badge>
                      )}
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-2 pt-4 border-t border-gray-200 dark:border-gray-700">
                  {selectedEvent.status === "live" ? (
                    <Button
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => {
                        onViewLive(selectedEvent.id);
                        setShowEventModal(false);
                      }}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View Live
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        onGenerateQR(selectedEvent.id);
                        setShowEventModal(false);
                      }}
                    >
                      <QrCode className="w-4 h-4 mr-2" />
                      QR Code
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      onEditEvent(selectedEvent.id);
                      setShowEventModal(false);
                    }}
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  {selectedEvent.status === "live" && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        onGenerateQR(selectedEvent.id);
                        setShowEventModal(false);
                      }}
                    >
                      <QrCode className="w-4 h-4 mr-2" />
                      QR Code
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                    onClick={() => {
                      onDeleteEvent(selectedEvent.id);
                      setShowEventModal(false);
                    }}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
