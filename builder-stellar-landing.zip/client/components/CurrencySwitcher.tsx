import { useTranslation } from "react-i18next";
import { useAppSettings, Currency } from "@/contexts/AppSettingsContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DollarSign } from "lucide-react";

export function CurrencySwitcher() {
  const { t } = useTranslation();
  const { currency, setCurrency } = useAppSettings();

  const currencies: { code: Currency; name: string; symbol: string }[] = [
    { code: "EUR", name: t("currencies.EUR"), symbol: "€" },
    { code: "USD", name: t("currencies.USD"), symbol: "$" },
  ];

  return (
    <Select
      value={currency}
      onValueChange={(value: Currency) => setCurrency(value)}
    >
      <SelectTrigger className="w-[180px]">
        <div className="flex items-center space-x-2">
          <DollarSign className="w-4 h-4" />
          <SelectValue />
        </div>
      </SelectTrigger>
      <SelectContent>
        {currencies.map((curr) => (
          <SelectItem key={curr.code} value={curr.code}>
            <div className="flex items-center space-x-2">
              <span>{curr.symbol}</span>
              <span>{curr.name}</span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
