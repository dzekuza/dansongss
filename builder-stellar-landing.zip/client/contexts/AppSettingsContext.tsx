import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";
import { useTranslation } from "react-i18next";

export type Language = "en" | "lt" | "ru";
export type Currency = "EUR" | "USD";

interface AppSettingsContextType {
  language: Language;
  currency: Currency;
  setLanguage: (language: Language) => void;
  setCurrency: (currency: Currency) => void;
  formatCurrency: (amount: number) => string;
  getCurrencySymbol: () => string;
}

const AppSettingsContext = createContext<AppSettingsContextType | undefined>(
  undefined,
);

export function AppSettingsProvider({ children }: { children: ReactNode }) {
  const { i18n } = useTranslation();
  const [language, setLanguageState] = useState<Language>("en");
  const [currency, setCurrencyState] = useState<Currency>("EUR");

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem(
      "eventflow_language",
    ) as Language;
    const savedCurrency = localStorage.getItem(
      "eventflow_currency",
    ) as Currency;

    if (savedLanguage && ["en", "lt", "ru"].includes(savedLanguage)) {
      setLanguageState(savedLanguage);
      i18n.changeLanguage(savedLanguage);
    }

    if (savedCurrency && ["EUR", "USD"].includes(savedCurrency)) {
      setCurrencyState(savedCurrency);
    }
  }, [i18n]);

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
    i18n.changeLanguage(newLanguage);
    localStorage.setItem("eventflow_language", newLanguage);
  };

  const setCurrency = (newCurrency: Currency) => {
    setCurrencyState(newCurrency);
    localStorage.setItem("eventflow_currency", newCurrency);
  };

  const getCurrencySymbol = () => {
    switch (currency) {
      case "EUR":
        return "€";
      case "USD":
        return "$";
      default:
        return "€";
    }
  };

  const formatCurrency = (amount: number) => {
    const symbol = getCurrencySymbol();
    const formattedAmount = amount.toFixed(2);

    // European format for EUR (symbol after), American format for USD (symbol before)
    if (currency === "EUR") {
      return `${formattedAmount}${symbol}`;
    } else {
      return `${symbol}${formattedAmount}`;
    }
  };

  return (
    <AppSettingsContext.Provider
      value={{
        language,
        currency,
        setLanguage,
        setCurrency,
        formatCurrency,
        getCurrencySymbol,
      }}
    >
      {children}
    </AppSettingsContext.Provider>
  );
}

export function useAppSettings() {
  const context = useContext(AppSettingsContext);
  if (context === undefined) {
    throw new Error(
      "useAppSettings must be used within an AppSettingsProvider",
    );
  }
  return context;
}
