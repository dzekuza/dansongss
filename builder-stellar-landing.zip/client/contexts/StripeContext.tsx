import { createContext, useContext, ReactNode } from "react";
import { loadStripe, Stripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";

// Initialize Stripe with your publishable key
const stripePromise = loadStripe(
  "pk_test_51HdSGwIyGqGwxSuNJx7WJCd4z3q2LkPHKm8vXJ9RjKq3J6HmRPDJz8VyNqQ9p7z9yQ2KrZnFjMqYxPtLhWQEwP00dJlMIVQe", // Replace with your actual Stripe public key
);

interface StripeContextType {
  stripe: Promise<Stripe | null>;
}

const StripeContext = createContext<StripeContextType | undefined>(undefined);

export function StripeProvider({ children }: { children: ReactNode }) {
  return (
    <Elements stripe={stripePromise}>
      <StripeContext.Provider value={{ stripe: stripePromise }}>
        {children}
      </StripeContext.Provider>
    </Elements>
  );
}

export function useStripe() {
  const context = useContext(StripeContext);
  if (context === undefined) {
    throw new Error("useStripe must be used within a StripeProvider");
  }
  return context;
}

// Subscription plan types
export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: "EUR" | "USD";
  interval: "month" | "year";
  features: string[];
  limits: {
    events?: number;
    teamMembers?: number;
  };
  popular?: boolean;
  stripePriceId: string;
}

// Subscription plans configuration
export const SUBSCRIPTION_PLANS: Record<string, SubscriptionPlan[]> = {
  individual: [
    {
      id: "individual-free",
      name: "Free",
      price: 0,
      currency: "EUR",
      interval: "month",
      features: [
        "Up to 3 events per month",
        "Basic QR code generation",
        "Email notifications",
        "Basic analytics",
      ],
      limits: {
        events: 3,
      },
      stripePriceId: "", // No Stripe price ID for free plan
    },
    {
      id: "individual-unlimited",
      name: "Unlimited",
      price: 19,
      currency: "EUR",
      interval: "month",
      features: [
        "Unlimited events",
        "Advanced QR code customization",
        "Priority email support",
        "Advanced analytics",
        "Custom branding",
        "Export capabilities",
      ],
      limits: {},
      popular: true,
      stripePriceId: "price_individual_unlimited_eur", // Replace with actual Stripe price ID
    },
  ],
  business: [
    {
      id: "business-free",
      name: "Free",
      price: 0,
      currency: "EUR",
      interval: "month",
      features: [
        "1 DJ, 1 Barista, 1 Host",
        "Up to 3 events per month",
        "Basic team management",
        "Email notifications",
        "Basic analytics",
      ],
      limits: {
        events: 3,
        teamMembers: 3,
      },
      stripePriceId: "", // No Stripe price ID for free plan
    },
    {
      id: "business-unlimited",
      name: "Business Pro",
      price: 19,
      currency: "EUR",
      interval: "month",
      features: [
        "Unlimited team members",
        "Unlimited events",
        "Advanced team management",
        "Role-based permissions",
        "Priority support",
        "Advanced analytics",
        "White-label options",
        "API access",
      ],
      limits: {},
      popular: true,
      stripePriceId: "price_business_unlimited_eur", // Replace with actual Stripe price ID
    },
  ],
};

// Convert EUR to USD (simplified - in real app, use live exchange rates)
export const convertCurrency = (
  amount: number,
  fromCurrency: "EUR" | "USD",
  toCurrency: "EUR" | "USD",
): number => {
  if (fromCurrency === toCurrency) return amount;

  // Simplified conversion rate (EUR to USD ≈ 1.1)
  if (fromCurrency === "EUR" && toCurrency === "USD") {
    return Math.round(amount * 1.1);
  }
  if (fromCurrency === "USD" && toCurrency === "EUR") {
    return Math.round(amount / 1.1);
  }

  return amount;
};

// Get plans for user role with currency conversion
export const getPlansForRole = (
  userRole: string,
  currency: "EUR" | "USD" = "EUR",
): SubscriptionPlan[] => {
  const roleKey = ["dj", "barista", "host"].includes(userRole)
    ? "individual"
    : "business";

  const plans = SUBSCRIPTION_PLANS[roleKey];

  return plans.map((plan) => ({
    ...plan,
    price: convertCurrency(plan.price, plan.currency, currency),
    currency,
  }));
};
