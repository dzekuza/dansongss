import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/contexts/AuthContext";
import { useAppSettings } from "@/contexts/AppSettingsContext";
import { getPlansForRole, SubscriptionPlan } from "@/contexts/StripeContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Check,
  Crown,
  Users,
  Calendar,
  Zap,
  Shield,
  BarChart3,
  Palette,
  Code,
  CreditCard,
  Star,
} from "lucide-react";

export default function Subscription() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { currency, formatCurrency } = useAppSettings();
  const [currentPlan] = useState("individual-free"); // This would come from user data
  const [loading, setLoading] = useState(false);

  if (!user) return null;

  const plans = getPlansForRole(user.role, currency);

  const handleSubscribe = async (plan: SubscriptionPlan) => {
    if (plan.price === 0) {
      // Handle free plan
      console.log("Switching to free plan:", plan.id);
      return;
    }

    setLoading(true);
    try {
      // Here you would integrate with Stripe
      console.log("Starting subscription for plan:", plan.id);

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // In real implementation, redirect to Stripe Checkout
      // const response = await fetch('/api/create-checkout-session', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ priceId: plan.stripePriceId })
      // });
      // const { url } = await response.json();
      // window.location.href = url;

      console.log("Subscription created successfully");
    } catch (error) {
      console.error("Error creating subscription:", error);
    } finally {
      setLoading(false);
    }
  };

  const getPlanIcon = (planId: string) => {
    if (planId.includes("free")) return Calendar;
    if (planId.includes("unlimited") || planId.includes("business"))
      return Crown;
    return Zap;
  };

  const getFeatureIcon = (feature: string) => {
    if (feature.toLowerCase().includes("event")) return Calendar;
    if (
      feature.toLowerCase().includes("team") ||
      feature.toLowerCase().includes("member")
    )
      return Users;
    if (feature.toLowerCase().includes("analytic")) return BarChart3;
    if (feature.toLowerCase().includes("support")) return Shield;
    if (
      feature.toLowerCase().includes("brand") ||
      feature.toLowerCase().includes("custom")
    )
      return Palette;
    if (feature.toLowerCase().includes("api")) return Code;
    return Check;
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-brand-purple to-brand-blue rounded-2xl flex items-center justify-center">
              <CreditCard className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {t("subscription.title")}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            {t("subscription.subtitle")}
          </p>
        </div>

        {/* Current Plan Status */}
        <Card className="mb-8 bg-gradient-to-r from-brand-purple/5 to-brand-blue/5 border-brand-purple/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-brand-purple/10 rounded-lg flex items-center justify-center">
                  <Star className="w-6 h-6 text-brand-purple" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    {t("subscription.currentPlan")}:{" "}
                    {plans.find((p) => p.id === currentPlan)?.name || "Free"}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {user.role === "company"
                      ? "Business account with team management"
                      : `${user.role.charAt(0).toUpperCase() + user.role.slice(1)} account`}
                  </p>
                </div>
              </div>
              <Button variant="outline">{t("subscription.manage")}</Button>
            </div>
          </CardContent>
        </Card>

        {/* Pricing Plans */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {plans.map((plan) => {
            const PlanIcon = getPlanIcon(plan.id);
            const isCurrentPlan = plan.id === currentPlan;
            const isFree = plan.price === 0;

            return (
              <Card
                key={plan.id}
                className={`relative transition-all duration-300 hover:shadow-xl ${
                  plan.popular
                    ? "border-brand-purple shadow-lg scale-105"
                    : "border-gray-200 dark:border-gray-700"
                } ${isCurrentPlan ? "ring-2 ring-brand-purple ring-opacity-50" : ""}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-brand-purple to-brand-blue text-white px-4 py-1">
                      {t("subscription.mostPopular")}
                    </Badge>
                  </div>
                )}
                {isCurrentPlan && (
                  <div className="absolute -top-4 right-4">
                    <Badge className="bg-green-500 text-white px-3 py-1">
                      {t("subscription.currentPlan")}
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-8 pt-8">
                  <div className="flex justify-center mb-4">
                    <div
                      className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                        plan.popular
                          ? "bg-gradient-to-br from-brand-purple to-brand-blue"
                          : "bg-gray-100 dark:bg-gray-800"
                      }`}
                    >
                      <PlanIcon
                        className={`w-8 h-8 ${
                          plan.popular
                            ? "text-white"
                            : "text-gray-600 dark:text-gray-400"
                        }`}
                      />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white">
                    {plan.name}
                  </CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-gray-900 dark:text-white">
                      {isFree
                        ? t("subscription.free")
                        : formatCurrency(plan.price)}
                    </span>
                    {!isFree && (
                      <span className="text-gray-600 dark:text-gray-400 ml-2">
                        {t("subscription.perMonth")}
                      </span>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="px-6 pb-8">
                  {/* Plan Limits */}
                  {(plan.limits.events || plan.limits.teamMembers) && (
                    <div className="mb-6">
                      <div className="space-y-2">
                        {plan.limits.events && (
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">
                              {plan.limits.events === 3
                                ? "3"
                                : t("subscription.unlimitedEvents")}
                            </span>
                            <Calendar className="w-4 h-4 text-gray-400" />
                          </div>
                        )}
                        {plan.limits.teamMembers && (
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">
                              {plan.limits.teamMembers === 3
                                ? "3"
                                : t("subscription.unlimitedTeamMembers")}
                            </span>
                            <Users className="w-4 h-4 text-gray-400" />
                          </div>
                        )}
                      </div>
                      <Separator className="mt-4 mb-6" />
                    </div>
                  )}

                  {/* Features List */}
                  <div className="space-y-3 mb-8">
                    {plan.features.map((feature, index) => {
                      const FeatureIcon = getFeatureIcon(feature);
                      return (
                        <div
                          key={index}
                          className="flex items-center space-x-3"
                        >
                          <FeatureIcon className="w-5 h-5 text-green-500 flex-shrink-0" />
                          <span className="text-gray-700 dark:text-gray-300 text-sm">
                            {feature}
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Action Button */}
                  <Button
                    onClick={() => handleSubscribe(plan)}
                    disabled={loading || isCurrentPlan}
                    className={`w-full ${
                      plan.popular
                        ? "bg-gradient-to-r from-brand-purple to-brand-blue hover:from-brand-purple-dark hover:to-brand-blue-dark"
                        : ""
                    }`}
                    variant={plan.popular ? "default" : "outline"}
                  >
                    {loading
                      ? t("common.loading")
                      : isCurrentPlan
                        ? t("subscription.currentPlan")
                        : isFree
                          ? t("subscription.choosePlan")
                          : t("subscription.upgrade")}
                  </Button>

                  {/* Additional Info */}
                  {!isFree && (
                    <div className="text-center mt-4 space-y-1">
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {t("subscription.cancelAnytime")}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {t("subscription.noCommitment")}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* FAQ Section */}
        <Card>
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">
                  Can I change my plan anytime?
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Yes, you can upgrade or downgrade your plan at any time.
                  Changes take effect immediately.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">
                  What payment methods do you accept?
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  We accept all major credit cards, PayPal, and bank transfers
                  through Stripe.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Is there a free trial?</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Our free plans allow you to test all basic features. No credit
                  card required.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">
                  Can I cancel my subscription?
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Yes, you can cancel anytime. You'll continue to have access
                  until the end of your billing period.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
