import { useState } from "react";
import { toast } from "@/hooks/use-toast";

interface EventNotificationData {
  to: string;
  eventName: string;
  eventDate: string;
  eventTime: string;
  venue: string;
  eventType: "dj" | "barista" | "host" | "company";
  recipientName: string;
  eventId: string;
  qrCodeUrl?: string;
  eventUrl?: string;
}

interface TeamInviteData {
  email: string;
  inviterName: string;
  role: string;
}

export function useEmailNotifications() {
  const [loading, setLoading] = useState(false);

  const sendEventCreatedNotification = async (
    data: EventNotificationData,
  ): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch("/api/notifications/event-created", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Email Sent",
          description: "Event creation notification sent successfully",
        });
        return true;
      } else {
        toast({
          title: "Email Failed",
          description: "Failed to send event notification",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error("Error sending event created notification:", error);
      toast({
        title: "Email Error",
        description: "An error occurred while sending the notification",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const sendEventReminderNotification = async (
    data: EventNotificationData,
  ): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch("/api/notifications/event-reminder", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Reminder Sent",
          description: "Event reminder notification sent successfully",
        });
        return true;
      } else {
        toast({
          title: "Reminder Failed",
          description: "Failed to send event reminder",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error("Error sending event reminder notification:", error);
      toast({
        title: "Reminder Error",
        description: "An error occurred while sending the reminder",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const sendEventUpdatedNotification = async (
    data: EventNotificationData,
  ): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch("/api/notifications/event-updated", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Update Sent",
          description: "Event update notification sent successfully",
        });
        return true;
      } else {
        toast({
          title: "Update Failed",
          description: "Failed to send event update",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error("Error sending event updated notification:", error);
      toast({
        title: "Update Error",
        description: "An error occurred while sending the update",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const sendQRCodeNotification = async (
    data: EventNotificationData,
  ): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch("/api/notifications/qr-code", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "QR Code Sent",
          description: "QR code notification sent successfully",
        });
        return true;
      } else {
        toast({
          title: "QR Code Failed",
          description: "Failed to send QR code notification",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error("Error sending QR code notification:", error);
      toast({
        title: "QR Code Error",
        description: "An error occurred while sending the QR code",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const sendTeamInviteNotification = async (
    data: TeamInviteData,
  ): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch("/api/notifications/team-invite", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Invitation Sent",
          description: `Team invitation sent to ${data.email}`,
        });
        return true;
      } else {
        toast({
          title: "Invitation Failed",
          description: "Failed to send team invitation",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error("Error sending team invite notification:", error);
      toast({
        title: "Invitation Error",
        description: "An error occurred while sending the invitation",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const sendTestEmail = async (email: string): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch("/api/notifications/test", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Test Email Sent",
          description: `Test email sent to ${email}`,
        });
        return true;
      } else {
        toast({
          title: "Test Email Failed",
          description: "Failed to send test email",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error("Error sending test email:", error);
      toast({
        title: "Test Email Error",
        description: "An error occurred while sending the test email",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    sendEventCreatedNotification,
    sendEventReminderNotification,
    sendEventUpdatedNotification,
    sendQRCodeNotification,
    sendTeamInviteNotification,
    sendTestEmail,
  };
}
