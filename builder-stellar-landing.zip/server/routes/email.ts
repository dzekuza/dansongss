import { RequestHandler } from "express";
import { z } from "zod";
import { emailService, EventNotificationData } from "../services/emailService";

// Validation schemas
const eventNotificationSchema = z.object({
  to: z.string().email(),
  eventName: z.string(),
  eventDate: z.string(),
  eventTime: z.string(),
  venue: z.string(),
  eventType: z.enum(["dj", "barista", "host", "company"]),
  recipientName: z.string(),
  eventId: z.string(),
  qrCodeUrl: z.string().optional(),
  eventUrl: z.string().optional(),
});

const teamInviteSchema = z.object({
  email: z.string().email(),
  inviterName: z.string(),
  role: z.string(),
});

// Send event created notification
export const sendEventCreatedNotification: RequestHandler = async (
  req,
  res,
) => {
  try {
    const data = eventNotificationSchema.parse(req.body);

    const eventData: EventNotificationData = {
      eventName: data.eventName,
      eventDate: data.eventDate,
      eventTime: data.eventTime,
      venue: data.venue,
      eventType: data.eventType,
      recipientName: data.recipientName,
      eventId: data.eventId,
      qrCodeUrl: data.qrCodeUrl,
      eventUrl: data.eventUrl,
    };

    const success = await emailService.sendEventCreatedNotification(eventData);

    if (success) {
      res.json({ success: true, message: "Event created notification sent" });
    } else {
      res.status(500).json({ success: false, message: "Failed to send email" });
    }
  } catch (error) {
    console.error("Error sending event created notification:", error);
    res.status(400).json({ success: false, message: "Invalid request data" });
  }
};

// Send event reminder notification
export const sendEventReminderNotification: RequestHandler = async (
  req,
  res,
) => {
  try {
    const data = eventNotificationSchema.parse(req.body);

    const eventData: EventNotificationData = {
      eventName: data.eventName,
      eventDate: data.eventDate,
      eventTime: data.eventTime,
      venue: data.venue,
      eventType: data.eventType,
      recipientName: data.recipientName,
      eventId: data.eventId,
      qrCodeUrl: data.qrCodeUrl,
      eventUrl: data.eventUrl,
    };

    const success = await emailService.sendEventReminderNotification(eventData);

    if (success) {
      res.json({ success: true, message: "Event reminder notification sent" });
    } else {
      res.status(500).json({ success: false, message: "Failed to send email" });
    }
  } catch (error) {
    console.error("Error sending event reminder notification:", error);
    res.status(400).json({ success: false, message: "Invalid request data" });
  }
};

// Send event updated notification
export const sendEventUpdatedNotification: RequestHandler = async (
  req,
  res,
) => {
  try {
    const data = eventNotificationSchema.parse(req.body);

    const eventData: EventNotificationData = {
      eventName: data.eventName,
      eventDate: data.eventDate,
      eventTime: data.eventTime,
      venue: data.venue,
      eventType: data.eventType,
      recipientName: data.recipientName,
      eventId: data.eventId,
      qrCodeUrl: data.qrCodeUrl,
      eventUrl: data.eventUrl,
    };

    const success = await emailService.sendEventUpdatedNotification(eventData);

    if (success) {
      res.json({ success: true, message: "Event updated notification sent" });
    } else {
      res.status(500).json({ success: false, message: "Failed to send email" });
    }
  } catch (error) {
    console.error("Error sending event updated notification:", error);
    res.status(400).json({ success: false, message: "Invalid request data" });
  }
};

// Send QR code notification
export const sendQRCodeNotification: RequestHandler = async (req, res) => {
  try {
    const data = eventNotificationSchema.parse(req.body);

    const eventData: EventNotificationData = {
      eventName: data.eventName,
      eventDate: data.eventDate,
      eventTime: data.eventTime,
      venue: data.venue,
      eventType: data.eventType,
      recipientName: data.recipientName,
      eventId: data.eventId,
      qrCodeUrl: data.qrCodeUrl,
      eventUrl: data.eventUrl,
    };

    const success = await emailService.sendQRCodeNotification(eventData);

    if (success) {
      res.json({ success: true, message: "QR code notification sent" });
    } else {
      res.status(500).json({ success: false, message: "Failed to send email" });
    }
  } catch (error) {
    console.error("Error sending QR code notification:", error);
    res.status(400).json({ success: false, message: "Invalid request data" });
  }
};

// Send team invite notification
export const sendTeamInviteNotification: RequestHandler = async (req, res) => {
  try {
    const data = teamInviteSchema.parse(req.body);

    const success = await emailService.sendTeamInviteNotification(
      data.email,
      data.inviterName,
      data.role,
    );

    if (success) {
      res.json({ success: true, message: "Team invite notification sent" });
    } else {
      res.status(500).json({ success: false, message: "Failed to send email" });
    }
  } catch (error) {
    console.error("Error sending team invite notification:", error);
    res.status(400).json({ success: false, message: "Invalid request data" });
  }
};

// Test email endpoint
export const sendTestEmail: RequestHandler = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res
        .status(400)
        .json({ success: false, message: "Email is required" });
    }

    const success = await emailService.sendTestEmail(email);

    if (success) {
      res.json({ success: true, message: "Test email sent successfully" });
    } else {
      res.status(500).json({ success: false, message: "Failed to send email" });
    }
  } catch (error) {
    console.error("Error sending test email:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};
