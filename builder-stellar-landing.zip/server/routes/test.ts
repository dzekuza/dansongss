import { RequestHandler } from "express";
import { emailService } from "../services/emailService";

// Test endpoint for team invite
export const testEmailRoute: RequestHandler = async (req, res) => {
  try {
    const result = await emailService.sendTeamInviteNotification(
      "dzekuza@gmail.com",
      "EventFlow Admin",
      "dj",
    );

    if (result) {
      res.json({
        success: true,
        message: "Test team invite sent to dzekuza@gmail.com successfully!",
      });
    } else {
      res.status(500).json({
        success: false,
        message: "Failed to send test email",
      });
    }
  } catch (error) {
    console.error("Error in test email route:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Test endpoint for event creation email
export const testEventCreationRoute: RequestHandler = async (req, res) => {
  try {
    const mockEvent = {
      title: "Test Event Creation",
      description:
        "This is a test event to verify email notifications are working",
      date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 1 week from now
      location: "Test Venue",
      type: "party" as const,
      maxParticipants: 50,
      ticketPrice: 25,
      currency: "EUR" as const,
    };

    const result = await emailService.sendEventCreatedNotification(
      "dzekuza@gmail.com",
      "Test User",
      mockEvent,
    );

    if (result) {
      res.json({
        success: true,
        message:
          "Test event creation email sent to dzekuza@gmail.com successfully!",
        event: mockEvent,
      });
    } else {
      res.status(500).json({
        success: false,
        message: "Failed to send test event creation email",
      });
    }
  } catch (error) {
    console.error("Error in test event creation route:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};
