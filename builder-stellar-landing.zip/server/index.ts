import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import {
  sendEventCreatedNotification,
  sendEventReminderNotification,
  sendEventUpdatedNotification,
  sendQRCodeNotification,
  sendTeamInviteNotification,
  sendTestEmail,
} from "./routes/email";
import { testEmailRoute, testEventCreationRoute } from "./routes/test";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    res.json({ message: "Hello from Express server v2!" });
  });

  app.get("/api/demo", handleDemo);

  // Email notification routes
  app.post("/api/notifications/event-created", sendEventCreatedNotification);
  app.post("/api/notifications/event-reminder", sendEventReminderNotification);
  app.post("/api/notifications/event-updated", sendEventUpdatedNotification);
  app.post("/api/notifications/qr-code", sendQRCodeNotification);
  app.post("/api/notifications/team-invite", sendTeamInviteNotification);
  app.post("/api/notifications/test", sendTestEmail);

  // Test routes for email functionality
  app.get("/api/test-team-invite", testEmailRoute);
  app.get("/api/test-event-creation", testEventCreationRoute);

  return app;
}
