import { Resend } from "resend";

// Initialize Resend with API key from environment variables
// Use a fallback key for development if not provided
const resend = new Resend(process.env.RESEND_API_KEY || "re_development_key");

export interface EmailNotification {
  to: string[];
  subject: string;
  html: string;
  from?: string;
}

export interface EventNotificationData {
  eventName: string;
  eventDate: string;
  eventTime: string;
  venue: string;
  eventType: "dj" | "barista" | "host" | "company";
  recipientName: string;
  eventId: string;
  qrCodeUrl?: string;
  eventUrl?: string;
}

class EmailService {
  private defaultFrom = "EventFlow <notifications@teamup.lt>";

  private isConfigured(): boolean {
    const apiKey = process.env.RESEND_API_KEY;
    return apiKey && apiKey !== "re_development_key";
  }

  async sendEventCreatedNotification(
    email: string,
    recipientName: string,
    eventData: {
      title: string;
      description?: string;
      date: Date;
      location: string;
      type: string;
      maxParticipants?: number;
      ticketPrice?: number;
      currency?: string;
    },
  ): Promise<boolean> {
    if (!this.isConfigured()) {
      console.warn("Resend API key not configured. Email sending disabled.");
      return true; // Return true to not break the flow
    }

    try {
      const data: EventNotificationData = {
        eventName: eventData.title,
        eventDate: eventData.date.toLocaleDateString(),
        eventTime: eventData.date.toLocaleTimeString(),
        venue: eventData.location,
        eventType: eventData.type as "dj" | "barista" | "host" | "company",
        recipientName: recipientName,
        eventId: "evt-" + Date.now(),
        eventUrl: `https://app.teamup.lt/events/evt-${Date.now()}`,
      };

      const html = this.generateEventCreatedTemplate(data);

      await resend.emails.send({
        from: this.defaultFrom,
        to: [email],
        subject: `New Event Created: ${data.eventName}`,
        html,
      });

      return true;
    } catch (error) {
      console.error("Failed to send event created notification:", error);
      return false;
    }
  }

  async sendEventReminderNotification(
    data: EventNotificationData,
  ): Promise<boolean> {
    if (!this.isConfigured()) {
      console.warn("Resend API key not configured. Email sending disabled.");
      return true;
    }

    try {
      const html = this.generateEventReminderTemplate(data);

      await resend.emails.send({
        from: this.defaultFrom,
        to: data.recipientName ? [data.recipientName] : [],
        subject: `Event Reminder: ${data.eventName} - Tomorrow`,
        html,
      });

      return true;
    } catch (error) {
      console.error("Failed to send event reminder notification:", error);
      return false;
    }
  }

  async sendEventUpdatedNotification(
    data: EventNotificationData,
  ): Promise<boolean> {
    if (!this.isConfigured()) {
      console.warn("Resend API key not configured. Email sending disabled.");
      return true;
    }

    try {
      const html = this.generateEventUpdatedTemplate(data);

      await resend.emails.send({
        from: this.defaultFrom,
        to: data.recipientName ? [data.recipientName] : [],
        subject: `Event Updated: ${data.eventName}`,
        html,
      });

      return true;
    } catch (error) {
      console.error("Failed to send event updated notification:", error);
      return false;
    }
  }

  async sendQRCodeNotification(data: EventNotificationData): Promise<boolean> {
    if (!this.isConfigured()) {
      console.warn("Resend API key not configured. Email sending disabled.");
      return true;
    }

    try {
      const html = this.generateQRCodeTemplate(data);

      await resend.emails.send({
        from: this.defaultFrom,
        to: data.recipientName ? [data.recipientName] : [],
        subject: `QR Code for ${data.eventName}`,
        html,
      });

      return true;
    } catch (error) {
      console.error("Failed to send QR code notification:", error);
      return false;
    }
  }

  async sendTeamInviteNotification(
    email: string,
    inviterName: string,
    role: string,
  ): Promise<boolean> {
    if (!this.isConfigured()) {
      console.warn("Resend API key not configured. Email sending disabled.");
      return true;
    }

    try {
      const html = this.generateTeamInviteTemplate(inviterName, role);

      await resend.emails.send({
        from: this.defaultFrom,
        to: [email],
        subject: `You've been invited to join EventFlow`,
        html,
      });

      return true;
    } catch (error) {
      console.error("Failed to send team invite notification:", error);
      return false;
    }
  }

  private generateEventCreatedTemplate(data: EventNotificationData): string {
    const typeEmoji = this.getEventTypeEmoji(data.eventType);

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Event Created - EventFlow</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
          .container { max-width: 600px; margin: 0 auto; background-color: white; }
          .header { background: linear-gradient(135deg, #8b5cf6 0%, #3b82f6 100%); padding: 40px 30px; text-align: center; }
          .header h1 { color: white; margin: 0; font-size: 28px; font-weight: bold; }
          .content { padding: 40px 30px; }
          .event-card { background-color: #f8fafc; border-radius: 12px; padding: 24px; margin: 24px 0; border-left: 4px solid #8b5cf6; }
          .event-title { font-size: 24px; font-weight: bold; color: #1f2937; margin: 0 0 8px 0; }
          .event-details { margin: 16px 0; }
          .detail-row { display: flex; align-items: center; margin: 8px 0; color: #6b7280; }
          .detail-icon { margin-right: 8px; font-size: 16px; }
          .cta-button { display: inline-block; background: linear-gradient(135deg, #8b5cf6 0%, #3b82f6 100%); color: white; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; margin: 20px 0; }
          .footer { background-color: #f8fafc; padding: 20px 30px; text-align: center; color: #6b7280; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${typeEmoji} Event Created Successfully!</h1>
          </div>
          <div class="content">
            <p>Hello ${data.recipientName || "there"},</p>
            <p>Your event has been created successfully in EventFlow. Here are the details:</p>
            
            <div class="event-card">
              <h2 class="event-title">${data.eventName}</h2>
              <div class="event-details">
                <div class="detail-row">
                  <span class="detail-icon">📍</span>
                  <span>${data.venue}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">📅</span>
                  <span>${data.eventDate}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">🕒</span>
                  <span>${data.eventTime}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">${typeEmoji}</span>
                  <span>${data.eventType.charAt(0).toUpperCase() + data.eventType.slice(1)} Event</span>
                </div>
              </div>
            </div>

            <p>You can now:</p>
            <ul>
              <li>Generate QR codes for easy access</li>
              <li>Share event details with participants</li>
              <li>Track real-time activity during the event</li>
              <li>Manage your event from the dashboard</li>
            </ul>

            ${data.eventUrl ? `<a href="${data.eventUrl}" class="cta-button">View Event Details</a>` : ""}
          </div>
          <div class="footer">
            <p>This email was sent by EventFlow</p>
            <p>© 2024 EventFlow. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  private generateEventReminderTemplate(data: EventNotificationData): string {
    const typeEmoji = this.getEventTypeEmoji(data.eventType);

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Event Reminder - EventFlow</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
          .container { max-width: 600px; margin: 0 auto; background-color: white; }
          .header { background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%); padding: 40px 30px; text-align: center; }
          .header h1 { color: white; margin: 0; font-size: 28px; font-weight: bold; }
          .content { padding: 40px 30px; }
          .event-card { background-color: #fef3c7; border-radius: 12px; padding: 24px; margin: 24px 0; border-left: 4px solid #f59e0b; }
          .event-title { font-size: 24px; font-weight: bold; color: #1f2937; margin: 0 0 8px 0; }
          .reminder-text { color: #d97706; font-weight: 600; font-size: 18px; margin: 16px 0; }
          .event-details { margin: 16px 0; }
          .detail-row { display: flex; align-items: center; margin: 8px 0; color: #6b7280; }
          .detail-icon { margin-right: 8px; font-size: 16px; }
          .cta-button { display: inline-block; background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%); color: white; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; margin: 20px 0; }
          .footer { background-color: #f8fafc; padding: 20px 30px; text-align: center; color: #6b7280; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>⏰ Event Reminder</h1>
          </div>
          <div class="content">
            <p>Hello ${data.recipientName || "there"},</p>
            <p class="reminder-text">Your event is tomorrow!</p>
            
            <div class="event-card">
              <h2 class="event-title">${data.eventName}</h2>
              <div class="event-details">
                <div class="detail-row">
                  <span class="detail-icon">📍</span>
                  <span>${data.venue}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">📅</span>
                  <span>${data.eventDate}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">🕒</span>
                  <span>${data.eventTime}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">${typeEmoji}</span>
                  <span>${data.eventType.charAt(0).toUpperCase() + data.eventType.slice(1)} Event</span>
                </div>
              </div>
            </div>

            <p><strong>Don't forget to:</strong></p>
            <ul>
              <li>Prepare your equipment and materials</li>
              <li>Check the venue details and arrival time</li>
              <li>Generate QR codes if needed</li>
              <li>Review event requirements</li>
            </ul>

            ${data.eventUrl ? `<a href="${data.eventUrl}" class="cta-button">View Event Details</a>` : ""}
          </div>
          <div class="footer">
            <p>This email was sent by EventFlow</p>
            <p>© 2024 EventFlow. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  private generateEventUpdatedTemplate(data: EventNotificationData): string {
    const typeEmoji = this.getEventTypeEmoji(data.eventType);

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Event Updated - EventFlow</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
          .container { max-width: 600px; margin: 0 auto; background-color: white; }
          .header { background: linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%); padding: 40px 30px; text-align: center; }
          .header h1 { color: white; margin: 0; font-size: 28px; font-weight: bold; }
          .content { padding: 40px 30px; }
          .event-card { background-color: #e0f2fe; border-radius: 12px; padding: 24px; margin: 24px 0; border-left: 4px solid #06b6d4; }
          .event-title { font-size: 24px; font-weight: bold; color: #1f2937; margin: 0 0 8px 0; }
          .update-notice { color: #0891b2; font-weight: 600; font-size: 16px; margin: 16px 0; }
          .event-details { margin: 16px 0; }
          .detail-row { display: flex; align-items: center; margin: 8px 0; color: #6b7280; }
          .detail-icon { margin-right: 8px; font-size: 16px; }
          .cta-button { display: inline-block; background: linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%); color: white; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; margin: 20px 0; }
          .footer { background-color: #f8fafc; padding: 20px 30px; text-align: center; color: #6b7280; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>📝 Event Updated</h1>
          </div>
          <div class="content">
            <p>Hello ${data.recipientName || "there"},</p>
            <p class="update-notice">Your event details have been updated.</p>
            
            <div class="event-card">
              <h2 class="event-title">${data.eventName}</h2>
              <div class="event-details">
                <div class="detail-row">
                  <span class="detail-icon">📍</span>
                  <span>${data.venue}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">📅</span>
                  <span>${data.eventDate}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">🕒</span>
                  <span>${data.eventTime}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-icon">${typeEmoji}</span>
                  <span>${data.eventType.charAt(0).toUpperCase() + data.eventType.slice(1)} Event</span>
                </div>
              </div>
            </div>

            <p>Please review the updated details and make any necessary adjustments to your preparations.</p>

            ${data.eventUrl ? `<a href="${data.eventUrl}" class="cta-button">View Updated Event</a>` : ""}
          </div>
          <div class="footer">
            <p>This email was sent by EventFlow</p>
            <p>© 2024 EventFlow. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  private generateQRCodeTemplate(data: EventNotificationData): string {
    const typeEmoji = this.getEventTypeEmoji(data.eventType);

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>QR Code - EventFlow</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
          .container { max-width: 600px; margin: 0 auto; background-color: white; }
          .header { background: linear-gradient(135deg, #8b5cf6 0%, #3b82f6 100%); padding: 40px 30px; text-align: center; }
          .header h1 { color: white; margin: 0; font-size: 28px; font-weight: bold; }
          .content { padding: 40px 30px; text-align: center; }
          .qr-section { background-color: #f8fafc; border-radius: 12px; padding: 24px; margin: 24px 0; }
          .qr-code { max-width: 200px; height: auto; margin: 20px auto; border: 1px solid #e5e7eb; border-radius: 8px; }
          .event-title { font-size: 24px; font-weight: bold; color: #1f2937; margin: 16px 0; }
          .instructions { color: #6b7280; line-height: 1.6; margin: 20px 0; }
          .footer { background-color: #f8fafc; padding: 20px 30px; text-align: center; color: #6b7280; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>📱 Your Event QR Code</h1>
          </div>
          <div class="content">
            <p>Hello ${data.recipientName || "there"},</p>
            
            <div class="qr-section">
              <h2 class="event-title">${typeEmoji} ${data.eventName}</h2>
              ${data.qrCodeUrl ? `<img src="${data.qrCodeUrl}" alt="QR Code for ${data.eventName}" class="qr-code" />` : `<div class="qr-code" style="background-color: #e5e7eb; display: flex; align-items: center; justify-content: center; color: #6b7280;">QR Code</div>`}
              
              <p class="instructions">
                <strong>How to use this QR Code:</strong><br>
                1. Print or display this QR code at your event<br>
                2. Guests can scan it with their phone camera<br>
                3. They'll be directed to interact with your ${data.eventType} services<br>
                4. Track all interactions in real-time from your dashboard
              </p>
            </div>

            <p><strong>Event Details:</strong></p>
            <p>${data.venue} • ${data.eventDate} at ${data.eventTime}</p>
          </div>
          <div class="footer">
            <p>This email was sent by EventFlow</p>
            <p>© 2024 EventFlow. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  private generateTeamInviteTemplate(
    inviterName: string,
    role: string,
  ): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Team Invitation - EventFlow</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
          .container { max-width: 600px; margin: 0 auto; background-color: white; }
          .header { background: linear-gradient(135deg, #10b981 0%, #3b82f6 100%); padding: 40px 30px; text-align: center; }
          .header h1 { color: white; margin: 0; font-size: 28px; font-weight: bold; }
          .content { padding: 40px 30px; }
          .invite-card { background-color: #ecfdf5; border-radius: 12px; padding: 24px; margin: 24px 0; border-left: 4px solid #10b981; text-align: center; }
          .role-badge { display: inline-block; background-color: #10b981; color: white; padding: 8px 16px; border-radius: 20px; font-weight: 600; margin: 16px 0; }
          .cta-button { display: inline-block; background: linear-gradient(135deg, #10b981 0%, #3b82f6 100%); color: white; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; margin: 20px 0; }
          .footer { background-color: #f8fafc; padding: 20px 30px; text-align: center; color: #6b7280; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎉 You're Invited!</h1>
          </div>
          <div class="content">
            <p>Hello!</p>
            <p><strong>${inviterName}</strong> has invited you to join their team on EventFlow.</p>
            
            <div class="invite-card">
              <h2>Join as a ${role.charAt(0).toUpperCase() + role.slice(1)}</h2>
              <div class="role-badge">${role.toUpperCase()}</div>
              <p>You'll be able to manage events, track performance, and collaborate with your team.</p>
            </div>

            <p><strong>What you can do with EventFlow:</strong></p>
            <ul>
              <li>Create and manage events</li>
              <li>Generate QR codes for easy access</li>
              <li>Track real-time interactions</li>
              <li>Monitor earnings and analytics</li>
              <li>Collaborate with team members</li>
            </ul>

            <div style="text-align: center;">
              <a href="https://app.teamup.lt/register" class="cta-button">Accept Invitation</a>
            </div>
          </div>
          <div class="footer">
            <p>This email was sent by EventFlow</p>
            <p>© 2024 EventFlow. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  async sendTestEmail(email: string): Promise<boolean> {
    if (!this.isConfigured()) {
      console.warn("Resend API key not configured. Email sending disabled.");
      return true; // Return true to not break the flow
    }

    try {
      const testData: EventNotificationData = {
        eventName: "Test Event - Email Configuration",
        eventDate: "December 25, 2024",
        eventTime: "7:00 PM",
        venue: "Test Venue - EventFlow HQ",
        eventType: "dj",
        recipientName: email.split("@")[0], // Use part before @ as name
        eventId: "test-email-123",
        eventUrl: "https://app.teamup.lt/events/test-email-123",
      };

      const html = this.generateEventCreatedTemplate(testData);

      await resend.emails.send({
        from: this.defaultFrom,
        to: [email],
        subject: "✅ Test Email from EventFlow - Configuration Successful",
        html,
      });

      console.log(`Test email sent successfully to ${email}`);
      return true;
    } catch (error) {
      console.error("Error sending test email:", error);
      return false;
    }
  }

  private getEventTypeEmoji(type: string): string {
    switch (type) {
      case "dj":
        return "🎵";
      case "barista":
        return "☕";
      case "host":
        return "🎤";
      case "company":
        return "🏢";
      default:
        return "📅";
    }
  }
}

export const emailService = new EmailService();
