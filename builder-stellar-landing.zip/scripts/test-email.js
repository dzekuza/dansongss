#!/usr/bin/env node

// Test script to send team member invite notification
const fetch = require("node-fetch");

const API_BASE_URL = "http://localhost:8080";

async function sendTestTeamInvite() {
  try {
    console.log("🚀 Sending test team member invite notification...");

    const response = await fetch(
      `${API_BASE_URL}/api/notifications/team-invite`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: "dzekuza@gmail.com",
          inviterName: "EventFlow Admin",
          role: "dj",
        }),
      },
    );

    const result = await response.json();

    if (response.ok && result.success) {
      console.log(
        "✅ Success! Team invite notification sent to dzekuza@gmail.com",
      );
      console.log("📧 Message:", result.message);
    } else {
      console.error("❌ Failed to send email");
      console.error("Error:", result.message || "Unknown error");
    }
  } catch (error) {
    console.error("❌ Error sending test email:", error.message);
    console.log(
      "\n💡 Make sure the development server is running (npm run dev)",
    );
  }
}

// Run the test
sendTestTeamInvite();
